# Cek Website Vercel

Simple web menggunakan **Next.js** untuk mengecek apakah website berjalan atau tidak.
Project ini siap di-upload ke GitHub dan langsung di-deploy ke Vercel.

## Fitur

- Halaman utama status website
- API health check di `/api/health`
- Siap deploy ke Vercel
- Tanpa database
- Struktur sederhana dan ringan

## Struktur Folder

```txt
cek-website-vercel/
├── app/
│   ├── api/
│   │   └── health/
│   │       └── route.js
│   ├── globals.css
│   ├── layout.js
│   └── page.js
├── .gitignore
├── next.config.js
├── package.json
└── README.md
```

## Jalankan di Local

```bash
npm install
npm run dev
```

Buka:

```txt
http://localhost:3000
```

Cek API:

```txt
http://localhost:3000/api/health
```

## Deploy ke Vercel

1. Upload semua file ke GitHub.
2. Buka https://vercel.com.
3. Klik **Add New Project**.
4. Pilih repository GitHub project ini.
5. Klik **Deploy**.

Vercel akan otomatis membaca project Next.js ini.

## Endpoint API

`GET /api/health`

Contoh response:

```json
{
  "status": "online",
  "website": "running",
  "api": "active",
  "message": "Website Next.js berjalan normal di Vercel.",
  "time": "2026-06-10T00:00:00.000Z"
}
```
